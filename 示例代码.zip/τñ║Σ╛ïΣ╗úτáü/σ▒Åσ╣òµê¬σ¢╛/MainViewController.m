
//
//  MainViewController.m
//  屏幕截图
//
//  Created by ZhangCheng on 14-4-5.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "MainViewController.h"
#import "ZCScreenShot.h"
@interface MainViewController ()

@end

@implementation MainViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIButton*button=[UIButton buttonWithType:UIButtonTypeCustom];
    button.backgroundColor=[UIColor redColor];
    [button setTitle:@"屏幕截图" forState:UIControlStateNormal];
    button.frame=CGRectMake(100, 100, 100, 100);
    [self.view addSubview:button];
    [button addTarget:self action:@selector(buttonClick) forControlEvents:UIControlEventTouchUpInside];
    
}
-(void)buttonClick{
 UIImage*image=   [ZCScreenShot beginImageContext:self.view.frame View:self.view];
    
    UIImageWriteToSavedPhotosAlbum(image, nil, nil,nil);
    UIAlertView*al=[[UIAlertView alloc]initWithTitle:@"告知" message:@"消息已经保存在相册中" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil];
    [al show];

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
